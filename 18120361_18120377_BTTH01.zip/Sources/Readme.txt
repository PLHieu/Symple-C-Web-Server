Chạy file WebServer.exe ở thư mục Build để mở Server
Giữ nguyên cấu trúc cây thư mục để đảm bảo Server hoạt động được